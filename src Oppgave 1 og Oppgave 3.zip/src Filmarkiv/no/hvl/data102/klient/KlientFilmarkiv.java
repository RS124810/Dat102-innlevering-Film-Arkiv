package no.hvl.data102.klient;

public class KlientFilmarkiv {

	public static void main(String[] args) {
	
	Meny meny = new Meny ();
	meny.Start();
	}

}
